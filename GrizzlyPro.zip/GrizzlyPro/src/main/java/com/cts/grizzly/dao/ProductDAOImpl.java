package com.cts.grizzly.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzly.bean.Product;
import com.cts.grizzly.bean.*;

@Repository("productDAO")
@Transactional(propagation=Propagation.SUPPORTS)
public class ProductDAOImpl implements ProductDAO{

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory ;
	
	@Transactional
	public String addProduct(Product product) {
	
		Session session = null;
		
		try{
			session = sessionFactory.getCurrentSession();
			session.save(product);
			return "success";
		} catch(Exception e){
			
			e.printStackTrace();
			return "fail";
		} finally{
			
		}
	}

	@Transactional
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		List<Product> list=new ArrayList<Product>();
		Session session=null;
		
		session=sessionFactory.getCurrentSession();
		String stringQuery="from Product";
		Query query=session.createQuery(stringQuery);
		list=query.getResultList();
		
		return list;
	}

	
	@Transactional
	public Product findProduct(String id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession();
	    Query query=session.createQuery("from product where productId=:id");
	    query.setParameter("id", id);
        return (Product) query.uniqueResult();
	}

	@Transactional
	public String deleteProduct(String productId) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.getCurrentSession() ;
		Query query=session.createQuery("from Product where productId=:id");
		query.setParameter("id", productId);
		Product product=(Product)query.getSingleResult();
		session.delete(product);
		return "true";
	}

	public List<Product> filterProducts(String query) {
		// TODO Auto-generated method stub
		return null;
	}

}
