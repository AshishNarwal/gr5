package com.cts.grizzly.service;

import com.cts.grizzly.bean.Login;

public interface LoginService {
	public boolean authentication(Login user);
}
